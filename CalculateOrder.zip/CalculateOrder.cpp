#include "Store.hpp"

/*  G. Add Inventory

    Calculate order the total for each item, Add them up for a sub-total 
    and calculate the tax (NYC is 8.875%) and the Grand Total.
*/

void Store::calculateOrder(string orderFile, string invFile){ // Order file and new inventory file as parameters
    vector<Store> store;    // Vector which use constructor of class to clasify data of Order File
    vector<Store> inventory;    // Vector which use constructor of class to clasify data of inventory
    int indexOrdVector = 0, indexInvVector = 0;
    Order order;        // Structure used to adjunt data of order file
    StoreInventory inv; // Structure used to adjunt data of inventory

    ifstream inOrderfile (orderFile), inInvfile (invFile);
    string line;

    if (inOrderfile.is_open() && inInvfile.is_open()){  // Opening two file at the same time
        getline(inOrderfile, line);
        getline(inInvfile, line);
        
        cout << setw(25) << left <<"Item ID Ordered";
        cout << setw(25) << left <<"Item Name Ordered";
        cout << setw(25) << left <<"Item Quantity Ordered";
        cout << setw(25) << left <<"Item Price Ordered" << endl;

        while(!inOrderfile.eof() && !inInvfile.eof()){
            // Data file being located in vector of order file
            inOrderfile >>   order.itemOrderedID >> order.itemOrderedName >> 
                        order.itemOrderedQuantity;
            auto itOrder = store.begin() + indexOrdVector;
            store.emplace(itOrder, order.itemOrderedName, order.itemOrderedQuantity);
            indexOrdVector ++;    
            // Data file being located in vector of Inventory
            inInvfile >> inv.itemID >> inv.itemName >> inv.itemQuantity >> inv.itemPrice;
            auto itInv = inventory.begin() + indexInvVector;
            inventory.emplace(itInv, inv.itemID, inv.itemName, order.itemOrderedQuantity, inv.itemPrice);
            indexInvVector ++;
        }
    }
    // Testing if file is Found
    else
        cout << "File Order \"" << orderFile << "\" Not Found" << endl;

    // Displaying data of Order File
    for (auto elementInv : inventory){
        cout << setw(25) << elementInv.getItemID();
        cout << setw(25) << elementInv.getName();
        cout << setw(25) << elementInv.getUnits();
        cout << setw(25) << elementInv.getRetailPrice() << endl;
        subTotal += elementInv.getUnits() * elementInv.getRetailPrice();
    }
    

    tax = subTotal * (TAXNYC * 0.01);
	total = (double)subTotal + (double)tax;

    cout << setprecision(4);
    cout << string(90, '-') << endl;
    cout  << setw(25) << "Sub-total: $";
    cout << setw(25) << subTotal << endl;
    cout << setw(25) << "Tax: $";
    cout << setw(25) << tax << endl;
    cout << string(90, '-') << endl;
    cout << setw(25) << "Total: $";
    cout << setw(25) << (double)total << endl;
    // Updating Inventory
    inventoryUpdate(orderFile, invFile);
}