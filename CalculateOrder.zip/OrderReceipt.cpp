#include "Store.hpp"

/*  C. Write to an out file and Screen with the sorted output of 5 items,   
    quantity, price and total for each item, sub-total, tax and grand 
    total. (Just like a receipt you get from the store)
    
*/
void Store::orderReceipt(string orderFile, string sumOrderFile){
    vector<Store> store;    // Vector which use constructor of class to clasify Order Receipt
    int indexVector = 0;
    Order order;    // Structure used to adjunt data of current order


    ifstream infile (orderFile);
    string line;

    if (infile.is_open()){
        getline(infile, line);
        while(!infile.eof()){
        // Data file being located in vector
        infile >>   order.itemOrderedID >> order.itemOrderedName >> 
                    order.itemOrderedQuantity;
        auto it = store.begin() + indexVector;
        store.emplace(it, order.itemOrderedName, order.itemOrderedQuantity);
        indexVector ++;
        }
    }
    // Testing if file is Found
    else
        cout << "File Order \"" << orderFile << "\" Not Found" << endl;

    infile.close();

    string sumOrder = sumOrderFile;
    ofstream outfile(sumOrder, ios::out);

    if(outfile.is_open()){

        // Display the vector contents

        outfile << string(40, '*') << endl;
        outfile << "******  S T O R E  R E C E I P T  ******" << endl;
        outfile << string(40, '*') << endl;

        outfile << setw(20) << left <<"Item Name Ordered";
        outfile << setw(20) << left <<"Item Quantity Ordered" << endl;

        for (auto element : store){
            outfile << setw(20) << element.getName();
            outfile << setw(20) << element.getUnits() << endl;
        }
        
        outfile << setprecision(4);
        outfile << string(40, '-') << endl;
        outfile  << setw(20) << "Sub-total: $";
        outfile << setw(20) << subTotal << endl;
        outfile << setw(20) << "Tax: $";
        outfile << setw(20) << tax << endl;
        outfile << string(40, '-') << endl;
        outfile << setw(20) << "Total: $";
        outfile << setw(20) << (double)total << endl;
        outfile << string(40, '*') << endl << endl;
    }
    outfile.close();
}