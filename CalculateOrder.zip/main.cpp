//  Giuseppe Marcoccio  
//  CSC 211 - 1900 
#include <iostream>
#include <iomanip>
#include <map>
#include "Store.hpp"                // Header File
#include "DisplayInventory.cpp"     // Displays Inventory at the beginning of the program
#include "SetOrder.cpp"             // Set the order from user file
#include "CalculateOrder.cpp"       // Calculate user Order and update inventory
#include "OrderReceipt.cpp"         // Export receipt to user file
#include "InventoryUpdate.cpp"      // Implementatoon of update inventory through recursive method
#include "DisplayOrder.cpp"         // Display specific order inserted
#include "AddInventory.cpp"         // Add more units to inventory from user file
using namespace std;


void DisplayMenu();             // Menu Display
map<int, string> mapOrder;      // Map creation in the global scope
void mapOrderSet(int, string);  // Map set for tracking orders
string mapOrderGet(int);        // Map get for tracking orders

int main(){
    char option;            // Menu option variable
    string orderFile;       // File that hold order from user
    string sumOrderFile;    // File that hold summary order exported
    int numKeyFile;         // Number Key File set tracking
    int oNum;               // Number key File get tracking
    string addnewInv;       // File that hold new Inventory
    

    cout << "\n\n\t\tWelcome to Giuseppe's Store" << endl;
    cout << "\n\nLoading Inventory...\n\n";

    Store store(0,"",0,0.0);    // Initialize class with none values

    store.displayInventory("Inventory.txt");    // Display Current Inventory

    cout << "\n\n";

    DisplayMenu();              // Display Menu
    cin >> option;

    do{                         // Do-While Loop for Menu
        
        switch (option){
            case 'A':   // Read from a file the Items bought Items ID,
            case 'a':   // Name, Quantity and Price
                cout << "\n\nPlease introduce the order file: ";
                cin >> orderFile;   // Order file from user
                cout << "\nPlease introduce number key for file: ";
                cin >> numKeyFile;  // Key File
                mapOrderSet(numKeyFile, orderFile); // Set Order file and Key File
                cout << "\n\nLoading Order # 1 from User...\n\n";
                store.setOrder(orderFile);
                cout << "\n\n";
                DisplayMenu();
                cin >> option;
            break;

            case 'B':   // Calculate order the total for each item, Add them up for a sub-total
            case 'b':   // and calculate the tax (NYC is 8.875%) and the Grand Total
                cout << "\n\nCalculating Order from User...\n\n";
                if (orderFile.empty()){
                    cout << "This option needs a Order File to work with\n";
                    cout << "Please select from menu option A and select your Order File.\n\n";
                    DisplayMenu();
                    cin >> option;
                }
                else {
                    store.calculateOrder(orderFile, "Inventory.txt");
                    cout << "\n\n";
                    DisplayMenu();
                    cin >> option;
                }
                
            break;
            
            case 'C':   // Write to an out file and Screen with the sorted output of 5 items,
            case 'c':   // quantity, price and total for each item, sub-total, tax and grand total.
                if (orderFile.empty()){
                    cout << "\nThis option needs a Order File to work with\n";
                    cout << "Please select from menu option A and select your Order File.\n\n";
                    DisplayMenu();
                    cin >> option;
                }
                else {
                    cout << "\n\nEnter Key Order File to Export #: ";
                    cin >> oNum;
                    cout << "\n\nEnter name of file to export: ";
                    cin >> sumOrderFile;
                    store.calculateOrder(mapOrderGet(oNum), "Inventory.txt");
                    store.orderReceipt(mapOrderGet(oNum), sumOrderFile);
                    cout << "\n\nOrder Exported to new file: " << sumOrderFile;
                    cout << "\n\n";
                    DisplayMenu();
                    cin >> option;
                }
            break;

            case 'D':   // Print out current inventory
            case 'd':
                cout << "\n\nCurrent Inventory\n\n";
                store.displayInventory("Inventory.txt");
                cout << "\n\n";
                DisplayMenu();
                cin >> option;
            break;

            case 'E':   // Find and Display items ordered using Order #
            case 'e':
                if (orderFile.empty()){
                    cout << "\nThis option needs a Order File to work with\n";
                    cout << "Please select from menu option A and select your Order File.\n\n";
                    DisplayMenu();
                    cin >> option;
                }
                else {
                    cout << "\n\nEnter the Order Number that you wish to display: ";
                    cout << "#";
                    cin >> oNum;
                    cout << "\n\nDisplaying Order #" << oNum << " ...\n\n";
                    store.displayOrder(mapOrderGet(oNum));
                    cout << "\n\n";
                    DisplayMenu();
                    cin >> option;
                }
            break;

            case 'F':   // New order
            case 'f':
                cout << "\n\nPlease introduce the order file: ";
                cin >> orderFile;
                cout << "\nPlease introduce number key for file: ";
                cin >> numKeyFile;
                mapOrderSet(numKeyFile, orderFile);
                cout << "\n\nLoading Order # " << numKeyFile << " from User...\n\n";
                store.setOrder(orderFile);
                cout << "\n\n";
                DisplayMenu();
                cin >> option;
            break;

            case 'G':   // Add Inventory
            case 'g':
                cout << "\n\nPlease introduce the New Inventory file: ";
                cin >> addnewInv;
                cout << "\n\nAdding new inventory..\n\n";
                store.addInventory("Inventory.txt", addnewInv);
                store.displayInventory("Inventory.txt");
                cout << "\n\n";
                DisplayMenu();
                cin >> option;
            break;
                
            //Program terminated based in the selection of the user.
            case 'H':   // Exit
            case 'h':
                cout << "\nProgram terminated"<<endl;
                return 0;
                break;

            //Validation of input from the user
            default:
                cout << "\n'" << option << "'" << "is not a valid choice\n" << endl;
                cout << "Please choose between letter A through H" << endl;
                DisplayMenu();
                cin >> option;
        }
        
    } while (option != 'E' || option != 'e');

    return 0;

}

void DisplayMenu(){
    cout << "A. Read from a file order of Items" << endl; 
    cout << "B. Calculate order the total" << endl;
    cout << "C. Export details of order to file" << endl;
    cout << "D. Print Current Inventory" << endl;
    cout << "E. Find and Display items ordered using Order #" << endl; 
    cout << "F. New order" << endl;
    cout << "G. Add Inventory" << endl;
    cout << "H. Exit" << endl;
    cout << "Election : ";
}

void mapOrderSet(int numKey, string numOrder){
    mapOrder.insert( pair<int, string>(numKey, numOrder));
}

string mapOrderGet(int num){
    if (mapOrder.count(num)){
        return mapOrder.at(num);
    }

    else 
        cout << "Invalid Number Key File" << endl;
    
    return "";
}