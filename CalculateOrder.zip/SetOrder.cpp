#include "Store.hpp"

/*  Set Order
    Definition: Display the Order from user
*/
void Store::setOrder(string orderFile){
    Order order;    // Using Structure

    ifstream infile (orderFile);    

    string line;

    if (infile.is_open()){  // Opening file

        getline(infile, line);  // Getting first line out

        cout << setw(20) << left <<"Item ID Ordered";
        cout << setw(20) << left <<"Item Name Ordered";
        cout << setw(20) << left <<"Quantity Ordered";
        cout<<endl;

        while(!infile.eof()){
        // Allocating fata into structure variables
        infile >>   order.itemOrderedID >> order.itemOrderedName >> 
                    order.itemOrderedQuantity;
        // Displaying data order
        cout << setw(20) << left << order.itemOrderedID;
        cout << setw(20) << left << order.itemOrderedName;
        cout << setw(20) << left << order.itemOrderedQuantity;
        cout<<endl;
        }
    }
    else{   // Test if file is not found
        cout << "File Order \"" << orderFile << "\" Not Found" << endl;
        cout << "Please re-enter file order name correctly: ";
        string fileName;
        cin >> fileName;
        cout << "\n\nLoading Order from User...\n\n";
        Store tryagain(0,"",0,0.0);
        tryagain.setOrder(fileName);    // Recursion function
    }

    infile.close();
}