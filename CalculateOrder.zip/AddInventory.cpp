#include "Store.hpp"

/*  G. Add Inventory

    This function definition is taking care about the constant updating
    of the Inventory inside our program.
*/

void Store::addInventory(string invFile, string addInvFile){    // Current Inventory file and new inventory file
    vector<Store> store;    // Vector which use constructor of class to clasify data of current inventory                
    vector<Store> inventory;    // Vector which use constructor of class to clasify data of new inventory
    int indexOrdVector = 0, indexInvVector = 0;
    Order order;        // Structure used to adjunt data of current inventory
    StoreInventory inv; // Structure used to adjunt data of current new inventory

    ifstream inInvFile (invFile), inAddInvfile (addInvFile);
    string line;

    if (inInvFile.is_open() && inAddInvfile.is_open()){// Opening two file at the same time
        getline(inInvFile, line);
        getline(inAddInvfile, line);
  
        while(!inInvFile.eof() && !inAddInvfile.eof()){ 
            // Data file being located in vector of current Inventory
            inInvFile >>   order.itemOrderedID >> order.itemOrderedName >> 
                        order.itemOrderedQuantity;
            auto itOrder = store.begin() + indexOrdVector;
            store.emplace(itOrder, order.itemOrderedName, order.itemOrderedQuantity);
            indexOrdVector ++;    
            // Data file being located in vector of current New Inventory
            inAddInvfile >> inv.itemID >> inv.itemName >> inv.itemQuantity >> inv.itemPrice;
            auto itInv = inventory.begin() + indexInvVector;        // Below addition of inventory new plus old.
            inventory.emplace(itInv, inv.itemID, inv.itemName, inv.itemQuantity + order.itemOrderedQuantity, inv.itemPrice);
            indexInvVector ++;  
        }
    }
    // Testing if file is Found
    else
        cout << "File Order \"" << invFile << "\" Not Found" << endl;
    
    inInvFile.close();
    inAddInvfile.close();

    ofstream outFile(invFile, ios::out);
    // Overwriting data of New Current Inventory
    if (outFile.is_open()){
        outFile << setw(25) << left <<"Item ID Ordered";
        outFile << setw(25) << left <<"Item Name Ordered";
        outFile << setw(25) << left <<"Item Quantity Ordered";
        outFile << setw(25) << left <<"Item Price Ordered" << endl;
    
        for (auto elementInv : inventory){
            outFile << setw(25) << elementInv.getItemID();
            outFile << setw(25) << elementInv.getName();
            outFile << setw(25) << elementInv.getUnits();
            outFile << setw(25) << elementInv.getRetailPrice() << endl;
        }
        
    }
    inInvFile.close();
}