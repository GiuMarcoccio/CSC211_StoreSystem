//  Giuseppe Marcoccio  
//  CSC 211 - 1900
#ifndef STORE_H
#define STORE_H
#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <string>
using namespace std;


double TAXNYC = 8.875;

struct StoreInventory{
   long itemID;
   string itemName;
   double itemQuantity;
   double itemPrice;
};

struct Order{
    long itemOrderedID;
    string itemOrderedName;
    double itemOrderedQuantity;
};

class Store{
    private: 
        int iD;
        string name;
        int units;
        double retailPrice;
        double subTotal= 0.0;
        double tax = 0.0;
        double total = 0.0;
    public:
        Store(int id, string n, int u, double rp){
            iD = id;
            name = n;
            units = u;
            retailPrice = rp;
        }
        Store(string n, int u){
            name = n;
            units = u;
        }
        void displayInventory(string);

        void setOrder(string);
        
        void inventoryUpdate(string, string);

        void calculateOrder(string, string);

        void orderReceipt(string, string);

        void displayOrder(string);

        void addInventory(string, string);

        void setItemID(int id){ iD = id; }
        void setName(string n){ name = n; }
        void setUnits(int u){ units = u; }
        void setRetailPrice(double rp){ retailPrice = rp; }
        int getItemID() const { return iD; }
        string getName() const { return name; }
        int getUnits() const { return units; }
        double getRetailPrice() const { return retailPrice; }

};

#endif