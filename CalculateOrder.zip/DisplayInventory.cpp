#include "Store.hpp"

/*  E. Find and Display items ordered using Order #

    This function definition is taking care about the displaying only
    the current Inventory
*/

void Store::displayInventory(string invFile){
    StoreInventory inv; // Structure used to adjunt data of current new inventory

    ifstream infile (invFile);

    string line;

    if (infile.is_open()){

        getline(infile, line); // Getting the first line out

        cout << setw(20) << left <<"Item ID";
        cout << setw(20) << left <<"Item Name";
        cout << setw(20) << left <<"Quantity";
        cout << setw(20) << left <<"Price Per Item";
        cout<<endl;

        while(!infile.eof()){
        // Data file being located Structure Inventory
        infile >> inv.itemID >> inv.itemName >> inv.itemQuantity >> inv.itemPrice;
        // Displaying data Inventory
        cout << setw(20) << left << inv.itemID;
        cout << setw(20) << left << inv.itemName;
        cout << setw(20) << left << inv.itemQuantity;
        cout << setw(20) << left << inv.itemPrice;
        cout<<endl;
        }
    }
    else{   // In case of error, EXIT
        cout << "Inventory Data Not Found" << endl;
        exit (EXIT_FAILURE);
    }

    infile.close(); 
}