#include "Store.hpp"

/*  Inventory Update
    
    Definition: Function that take care about the inventory subtracting
    items ordered by user.
*/

void Store::inventoryUpdate(string orderFile, string invFile){
    vector<Store> store;    // Vector which use constructor of class to clasify data of Order File
    vector<Store> inventory;    // Vector which use constructor of class to clasify data of inventory
    int indexOrdVector = 0, indexInvVector = 0;
    Order order;    // Structure used to adjunt data of order file
    StoreInventory inv; // Structure used to adjunt data of inventory

    ifstream inOrderfile (orderFile), inInvfile (invFile);
    string line;

    if (inOrderfile.is_open() && inInvfile.is_open()){  // Opening two file at the same time
        getline(inOrderfile, line);
        getline(inInvfile, line);
  
        while(!inOrderfile.eof() && !inInvfile.eof()){
            // Data file being located in vector of order file
            inOrderfile >>   order.itemOrderedID >> order.itemOrderedName >> 
                        order.itemOrderedQuantity;
            auto itOrder = store.begin() + indexOrdVector;
            store.emplace(itOrder, order.itemOrderedName, order.itemOrderedQuantity);
            indexOrdVector ++;    
            // Data file being located in vector of Inventory
            inInvfile >> inv.itemID >> inv.itemName >> inv.itemQuantity >> inv.itemPrice;
            auto itInv = inventory.begin() + indexInvVector;    // Below subtraction of inventory new plus old.
            inventory.emplace(itInv, inv.itemID, inv.itemName, inv.itemQuantity - order.itemOrderedQuantity, inv.itemPrice);
            indexInvVector ++;
        }
    }
    // Testing if file is Found
    else
        cout << "File Order \"" << orderFile << "\" Not Found" << endl;
    
    inOrderfile.close();
    inInvfile.close();

    ofstream outFile(invFile, ios::out);
    // Overwriting data of Inventory    
    if (outFile.is_open()){
        outFile << setw(25) << left <<"Item ID Ordered";
        outFile << setw(25) << left <<"Item Name Ordered";
        outFile << setw(25) << left <<"Item Quantity Ordered";
        outFile << setw(25) << left <<"Item Price Ordered" << endl;
    
        for (auto elementInv : inventory){
            outFile << setw(25) << elementInv.getItemID();
            outFile << setw(25) << elementInv.getName();
            outFile << setw(25) << elementInv.getUnits();
            outFile << setw(25) << elementInv.getRetailPrice() << endl;
        }
        
    }
    inOrderfile.close();
}