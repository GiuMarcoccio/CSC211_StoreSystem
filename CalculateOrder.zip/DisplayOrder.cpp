#include "Store.hpp"

/*  A. Read from a file the Items bought Items ID, Name, Quantity and Price

    Function definition: Function taking care of displaying Order from user */
void Store::displayOrder(string orderFile){
    Order order;    // Structure used to alocate the data from file

    ifstream infile (orderFile);

    string line;

    if (infile.is_open()){
        // Getting out first line
        getline(infile, line);

        cout << setw(20) << left <<"Item ID Ordered";
        cout << setw(20) << left <<"Item Name Ordered";
        cout << setw(20) << left <<"Quantity Ordered";
        cout<<endl;

        while(!infile.eof()){
            // Alocating data from file into structure variables
        infile >>   order.itemOrderedID >> order.itemOrderedName >> 
                    order.itemOrderedQuantity;

        cout << setw(20) << left << order.itemOrderedID;
        cout << setw(20) << left << order.itemOrderedName;
        cout << setw(20) << left << order.itemOrderedQuantity;
        cout<<endl;
        }
    }
    else{
        cout << "File Order \"" << orderFile << "\" Not Found" << endl;
    }
    infile.close();
}